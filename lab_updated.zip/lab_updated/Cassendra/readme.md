You’re essentially asking for a **complete, exam-ready Cassandra CQL reference with examples that covers everything you might need in lab + viva**. Below is a **structured, full-coverage guide** you can directly execute in:

👉 **cqlsh**

---

# 🚀 1. KEYSPACE (Database)

## Create Keyspace

```sql
CREATE KEYSPACE company
WITH replication = {'class':'SimpleStrategy','replication_factor':1};
```

## Use Keyspace

```sql
USE company;
```

## View Keyspaces

```sql
DESCRIBE KEYSPACES;
```

## Drop Keyspace

```sql
DROP KEYSPACE company;
```

---

# 🚀 2. TABLE (Column Family)

## Create Table

```sql
CREATE TABLE employee (
    emp_id INT PRIMARY KEY,
    name TEXT,
    dept TEXT,
    salary INT,
    join_date DATE
);
```

## View Tables

```sql
DESCRIBE TABLES;
```

## Describe Table

```sql
DESCRIBE employee;
```

---

# 🚀 3. INSERT OPERATIONS

## Single Insert

```sql
INSERT INTO employee (emp_id, name, dept, salary, join_date)
VALUES (101, 'Srujan', 'IT', 50000, '2023-01-10');
```

## Insert Multiple (Batch)

```sql
BEGIN BATCH
INSERT INTO employee VALUES (102, 'Ravi', 'HR', 60000, '2022-05-15');
INSERT INTO employee VALUES (103, 'Anita', 'Finance', 70000, '2021-07-20');
APPLY BATCH;
```

---

# 🚀 4. SELECT (READ)

## Select All

```sql
SELECT * FROM employee;
```

## Select with Condition (PRIMARY KEY only)

```sql
SELECT * FROM employee WHERE emp_id = 101;
```

## Limit

```sql
SELECT * FROM employee LIMIT 2;
```

---

# 🚀 5. UPDATE

```sql
UPDATE employee
SET salary = 55000, dept = 'Development'
WHERE emp_id = 101;
```

---

# 🚀 6. DELETE

```sql
DELETE FROM employee
WHERE emp_id = 103;
```

---

# 🚀 7. ALTER TABLE

## Add Column

```sql
ALTER TABLE employee ADD projects SET<TEXT>;
```

## Drop Column

```sql
ALTER TABLE employee DROP dept;
```

---

# 🚀 8. COLLECTION TYPES

## SET Example

```sql
UPDATE employee
SET projects = {'AI','ML'}
WHERE emp_id = 101;
```

## LIST Example

```sql
ALTER TABLE employee ADD skills LIST<TEXT>;

UPDATE employee
SET skills = ['Java','Python']
WHERE emp_id = 101;
```

## MAP Example

```sql
ALTER TABLE employee ADD marks MAP<TEXT, INT>;

UPDATE employee
SET marks = {'Math':90, 'DS':85}
WHERE emp_id = 101;
```

---

# 🚀 9. TTL (Time To Live)

```sql
INSERT INTO employee (emp_id, name, salary)
VALUES (200, 'TempUser', 30000)
USING TTL 15;
```

---

# 🚀 10. ORDER BY (Important)

⚠️ Only works with clustering column

### Proper Table

```sql
CREATE TABLE emp_sorted (
    dept TEXT,
    salary INT,
    name TEXT,
    PRIMARY KEY (dept, salary)
);
```

### Query

```sql
SELECT * FROM emp_sorted
WHERE dept = 'IT'
ORDER BY salary DESC;
```

---

# 🚀 11. INDEX

```sql
CREATE INDEX ON employee (dept);
```

```sql
SELECT * FROM employee WHERE dept = 'IT';
```

---

# 🚀 12. COUNTER TABLE

## Create

```sql
CREATE TABLE visits (
    user_id INT,
    page TEXT,
    visit_count COUNTER,
    PRIMARY KEY (user_id, page)
);
```

## Update Counter

```sql
UPDATE visits
SET visit_count = visit_count + 1
WHERE user_id = 1 AND page = 'Home';
```

---

# 🚀 13. TRUNCATE

```sql
TRUNCATE employee;
```

---

# 🚀 14. COPY (CSV)

## Export

```sql
COPY employee TO 'employee.csv' WITH HEADER = TRUE;
```

## Import

```sql
COPY employee FROM 'employee.csv' WITH HEADER = TRUE;
```

---

# 🚀 15. DROP

```sql
DROP TABLE employee;
```

---

# 🚀 16. FULL LAB EXAMPLE (IMPORTANT)

```sql
CREATE KEYSPACE lab WITH replication = {'class':'SimpleStrategy','replication_factor':1};
USE lab;

CREATE TABLE student (
    id INT PRIMARY KEY,
    name TEXT,
    marks INT
);

INSERT INTO student VALUES (1, 'A', 90);
INSERT INTO student VALUES (2, 'B', 85);

SELECT * FROM student;

UPDATE student SET marks = 95 WHERE id = 1;

DELETE FROM student WHERE id = 2;

ALTER TABLE student ADD grade TEXT;

UPDATE student SET grade = 'A' WHERE id = 1;
```

---

# ⚠️ VERY IMPORTANT VIVA POINTS

* No JOIN support
* No complex GROUP BY
* Must query using PRIMARY KEY
* Designed for **high write performance**
* Denormalization is used
* ORDER BY only with clustering column
* Counters are special (only with UPDATE)

---

# 🎯 What you now have

This covers:
✔ All CRUD
✔ Schema operations
✔ TTL
✔ Batch
✔ Counters
✔ Collections
✔ Index
✔ CSV
✔ Sorting
✔ Exam + viva points

---

## 👉 If you want next (high value)

I can:

* Convert this into **perfect lab record PDF format**
* OR give **expected outputs + screenshots style**
* OR take **your viva (very important questions professors ask)**
