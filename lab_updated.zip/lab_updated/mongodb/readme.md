Below is a **complete MongoDB query reference (CRUD + advanced)** with **clear examples**, structured for **lab + viva + exams**. You can run everything in:

👉 **MongoDB Shell**
👉 OR **MongoDB Compass**

---

# 🚀 1. DATABASE OPERATIONS

## Create / Switch Database

```javascript
use company
```

## Show Databases

```javascript
show dbs
```

## Current Database

```javascript
db
```

## Drop Database

```javascript
db.dropDatabase()
```

---

# 🚀 2. COLLECTION (TABLE)

## Create Collection

```javascript
db.createCollection("employee")
```

## Show Collections

```javascript
show collections
```

## Drop Collection

```javascript
db.employee.drop()
```

---

# 🚀 3. INSERT (CREATE)

## Insert One

```javascript
db.employee.insertOne({
  emp_id: 101,
  name: "Srujan",
  dept: "IT",
  salary: 50000
})
```

## Insert Many (Batch)

```javascript
db.employee.insertMany([
  { emp_id: 102, name: "Ravi", dept: "HR", salary: 60000 },
  { emp_id: 103, name: "Anita", dept: "Finance", salary: 70000 }
])
```

---

# 🚀 4. READ (SELECT)

## Select All

```javascript
db.employee.find()
```

## Pretty Format

```javascript
db.employee.find().pretty()
```

## Condition

```javascript
db.employee.find({ emp_id: 101 })
```

## Multiple Condition

```javascript
db.employee.find({ dept: "IT", salary: 50000 })
```

---

# 🚀 5. PROJECTION (Select specific fields)

```javascript
db.employee.find(
  { emp_id: 101 },
  { name: 1, salary: 1, _id: 0 }
)
```

---

# 🚀 6. UPDATE

## Update One

```javascript
db.employee.updateOne(
  { emp_id: 101 },
  { $set: { salary: 55000 } }
)
```

## Update Many

```javascript
db.employee.updateMany(
  { dept: "IT" },
  { $set: { dept: "Development" } }
)
```

---

# 🚀 7. DELETE

## Delete One

```javascript
db.employee.deleteOne({ emp_id: 103 })
```

## Delete Many

```javascript
db.employee.deleteMany({ dept: "HR" })
```

---

# 🚀 8. SORT

```javascript
db.employee.find().sort({ salary: -1 })
```

✔ -1 = descending
✔ 1 = ascending

---

# 🚀 9. LIMIT & SKIP

```javascript
db.employee.find().limit(2)
```

```javascript
db.employee.find().skip(1)
```

---

# 🚀 10. OPERATORS (VERY IMPORTANT)

## Comparison

```javascript
db.employee.find({ salary: { $gt: 50000 } })
```

| Operator | Meaning      |
| -------- | ------------ |
| $gt      | greater than |
| $lt      | less than    |
| $gte     | >=           |
| $lte     | <=           |
| $ne      | not equal    |

---

## Logical

```javascript
db.employee.find({
  $and: [{ dept: "IT" }, { salary: { $gt: 40000 } }]
})
```

```javascript
db.employee.find({
  $or: [{ dept: "HR" }, { salary: { $gt: 60000 } }]
})
```

---

# 🚀 11. ARRAY (IMPORTANT)

## Insert with Array

```javascript
db.employee.insertOne({
  emp_id: 200,
  name: "Kiran",
  projects: ["AI", "ML"]
})
```

## Query Array

```javascript
db.employee.find({ projects: "AI" })
```

## Add to Array

```javascript
db.employee.updateOne(
  { emp_id: 200 },
  { $push: { projects: "DL" } }
)
```

---

# 🚀 12. EMBEDDED DOCUMENT

```javascript
db.employee.insertOne({
  emp_id: 300,
  name: "Rahul",
  address: {
    city: "Bangalore",
    pincode: 560001
  }
})
```

Query:

```javascript
db.employee.find({ "address.city": "Bangalore" })
```

---

# 🚀 13. INDEX

## Create Index

```javascript
db.employee.createIndex({ dept: 1 })
```

## View Index

```javascript
db.employee.getIndexes()
```

---

# 🚀 14. AGGREGATION (IMPORTANT)

## Group + Count

```javascript
db.employee.aggregate([
  { $group: { _id: "$dept", total: { $sum: 1 } } }
])
```

## Average Salary

```javascript
db.employee.aggregate([
  { $group: { _id: "$dept", avgSalary: { $avg: "$salary" } } }
])
```

---

# 🚀 15. COUNT

```javascript
db.employee.countDocuments()
```

---

# 🚀 16. TTL (AUTO DELETE)

## Create TTL Index

```javascript
db.employee.createIndex(
  { createdAt: 1 },
  { expireAfterSeconds: 15 }
)
```

Insert:

```javascript
db.employee.insertOne({
  name: "Temp",
  createdAt: new Date()
})
```

---

# 🚀 17. UPSERT

```javascript
db.employee.updateOne(
  { emp_id: 500 },
  { $set: { name: "NewUser" } },
  { upsert: true }
)
```

---

# 🚀 18. EXPORT / IMPORT

## Export (Terminal)

```bash
mongoexport --db=company --collection=employee --out=emp.json
```

## Import

```bash
mongoimport --db=company --collection=employee --file=emp.json
```

---

# 🚀 19. FULL MINI LAB (IMPORTANT)

```javascript
use demo

db.createCollection("student")

db.student.insertMany([
  { id: 1, name: "A", marks: 90 },
  { id: 2, name: "B", marks: 85 }
])

db.student.find()

db.student.updateOne(
  { id: 1 },
  { $set: { marks: 95 } }
)

db.student.deleteOne({ id: 2 })
```

---

# ⚠️ VERY IMPORTANT VIVA POINTS

* MongoDB = **NoSQL (document-based)**
* Data stored as **JSON-like documents**
* Schema is **flexible**
* Uses **collections instead of tables**
* Supports **indexing + aggregation**
* Faster for **read-heavy apps**

---

# 🎯 What this covers

✔ CRUD
✔ Operators
✔ Sorting
✔ Arrays
✔ Embedded docs
✔ Aggregation
✔ Indexing
✔ TTL
✔ Import/Export
✔ Exam + viva ready

---

## 👉 If you want next (high value)

I can:

* Convert this into **perfect lab record format**
* OR give **your exact question answers (Employee + Library mapped to MongoDB)**
* OR conduct **viva questions (very tricky ones professors ask)**
